import { htmlToText } from "html-to-text";

export const parseBancolombiaEmail = (rawBody, mimeType) => {

  const body = cleanText(normalizeBody(rawBody, mimeType));

  const transaction = {
    type: null,
    description: null,
    merchant: null,
    amount: null,
    date: null
  };

  // =====================
  // RECIBISTE DINERO
  // =====================

  const income = body.match(
    /Recibiste\s+\$([\d,.]+).*?de\s+(.+?)\s+en\s+tu\s+cuenta/i
  );

  if (income) {
    transaction.type = "income";
    transaction.amount = parseAmount(income[1]);
    transaction.merchant = income[2].trim();
    transaction.description = `Pago recibido: ${transaction.merchant}`;
    transaction.date = extractDate(body);

    return transaction;
  }

  // =====================
  // COMPRA TARJETA
  // =====================

  const purchase = body.match(
    /Compra\s+por\s+\$([\d,.]+)\s+en\s+(.+?)\s+(?:con|en\s+tu\s+tarjeta)/i
  );

  if (purchase) {
    transaction.type = "expense";
    transaction.amount = parseAmount(purchase[1]);
    transaction.merchant = purchase[2].trim();
    transaction.description = `Compra en ${transaction.merchant}`;
    transaction.date = extractDate(body);

    return transaction;
  }

  // =====================
  // RETIRO CAJERO
  // =====================

  const withdrawal = body.match(
    /Retiraste\s+\$([\d,.]+)\s+de\s+tu\s+cuenta/i
  );

  if (withdrawal) {
    transaction.type = "expense";
    transaction.amount = parseAmount(withdrawal[1]);
    transaction.merchant = "Cajero";
    transaction.description = "Retiro cajero";
    transaction.date = extractDate(body);

    return transaction;
  }

  // =====================
  // TRANSFERENCIA ENVIADA
  // =====================

  const transfer = body.match(
    /Transferiste\s+\$([\d,.]+)\s+a\s+(.+?)\s+/i
  );

  if (transfer) {
    transaction.type = "transfer";
    transaction.amount = parseAmount(transfer[1]);
    transaction.merchant = transfer[2].trim();
    transaction.description = `Transferencia a ${transaction.merchant}`;
    transaction.date = extractDate(body);

    return transaction;
  }

  return null;
};



// =====================
// HELPERS
// =====================

function normalizeBody(body, mimeType) {

  if (mimeType === "text/html") {
    return htmlToText(body, {
      wordwrap: false,
      selectors: [{ selector: "img", format: "skip" }]
    });
  }

  return body;
}

function cleanText(text) {

  return text
    .replace(/\[https?:\/\/.*?\]/g, "")
    .replace(/Logo Bancolombia/gi, "")
    .replace(/yellow-icon/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

function parseAmount(value) {
  return Number(value.replace(/,/g, ""));
}

function extractDate(text) {

  const match = text.match(
    /(\d{4}\/\d{2}\/\d{2}).*?(\d{2}:\d{2})/
  );

  if (!match) return null;

  return new Date(`${match[1]} ${match[2]}`);
}